# swaggerFiles


Generate swagger ui embedded files by using:
```
make
```